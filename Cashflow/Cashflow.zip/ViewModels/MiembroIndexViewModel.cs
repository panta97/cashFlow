﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Cashflow.Models;

namespace Cashflow.ViewModels
{
    public class MiembroIndexViewModel
    {
        public Miembro Miembro { get; set; }
        public int Edad { get; set; }
    }


}