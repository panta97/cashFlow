﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Cashflow.Utils
{
    public class PieUtils
    {
        public static List<string> GetColors()
        {
            return new List<string>()
            {
                "rgba(253,141,50,1)",
                "rgba(254,196,69,1)",
                "rgba(63,180,179,1)",
                "rgba(45,143,230,1)",
                "rgba(252,72,113,1)",
                "rgba(253,141,50,1)",
                "rgba(254,196,69,1)",
                "rgba(63,180,179,1)",
                "rgba(45,143,230,1)",
                "rgba(252,72,113,1)"
            };
        }
    }
}