﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Cashflow.Models;

namespace Cashflow.Dtos
{
    public class MiembroDto
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
    }
}