﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Cashflow.Dtos
{
    public class MiembroEditDto
    {
        public int MiembroId { get; set; }
    }
}